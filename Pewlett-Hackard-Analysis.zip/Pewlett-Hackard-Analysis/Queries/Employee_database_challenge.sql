SELECT e.emp_no,
		e.first_name,
		e.last_name,
		t_tb.title, 
		t_tb.from_date,
		t_tb.to_date
INTO retirement_titles
FROM employees as e
INNER JOIN titles as t_tb
ON (e.emp_no = t_tb.emp_no)
WHERE (e.birth_date BETWEEN '1952-01-01' AND '1955-12-31')
ORDER BY t_tb.emp_no;


-- Use Dictinct with Orderby to remove duplicate rows
SELECT DISTINCT ON (emp_no)
emp_no,
first_name,
last_name,
title
INTO Unique_Titles
FROM retirement_titles
ORDER BY emp_no, to_date DESC;

--Display the number of each title
SELECT COUNT(emp_no),
title
INTO Retiring_titles
FROM unique_titles
GROUP BY title
ORDER BY count DESC;


--Mentorship Eligibility table
SELECT DISTINCT ON (e.emp_no)
		e.emp_no,
		e.first_name, 
		e.last_name,
		e.birth_date,
		de.from_date,
		de.to_date,
		t_tb.title
INTO mentorship_eligibilty
FROM employees as e
INNER JOIN dept_emp as de
ON (e.emp_no = de.emp_no)
INNER JOIN titles as t_tb
ON (e.emp_no = t_tb.emp_no)
WHERE (de.to_date = '9999-01-01')
AND (e.birth_date BETWEEN '1965-01-01' AND '1965-12-31')
GROUP BY (e.emp_no, de.from_date, de.to_date, t_tb.title)
ORDER BY e.emp_no;
		
-- Additional Quaries 

--Table of employees that have not reached retirement. 
SELECT e.emp_no, e.first_name, e.last_name, e.hire_date
INTO employees_not_retiring
FROM employees AS e
WHERE (hire_date BETWEEN '1990-01-01' AND '2000-12-31');

--Count of all the current titles in which departments that are not retiring.

SELECT COUNT(nr.emp_no),
t_tb.title,
d.dept_name
INTO count_of_titles_positions
FROM employees_not_retiring AS nr
LEFT JOIN titles as t_tb
ON (nr.emp_no = t_tb.emp_no)
LEFT JOIN dept_emp as de
ON (nr.emp_no = de.emp_no)
LEFT JOIN departments as d
ON (d.dept_no = de.dept_no)
GROUP BY (t_tb.title, de.dept_no, d.dept_name)
ORDER BY count DESC;
